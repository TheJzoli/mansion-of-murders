Thank you for purchasing Mansion of Murders!

You need to install Python 3.4 to play this game. You can download it for free from https://www.python.org/download/releases/3.4.0/.
Other versions of python may or may not work.

You can then play Mansion of Murders by running game.py and enjoy hours of enchanting bloodbath.

Sincerely
Mansion of Murders dev team