Thank you for purchasing Mansion of Murders text-adventure game!

To play, you need to have the following installed:
	Python 3.4	https://www.python.org/download/releases/3.4.0/
	MariaDB 10.2	https://downloads.mariadb.org/

Create root user to mariaDB and create database by running create_database_mariaDB.sql

You can play game by running game.py in python.
Game will teach you how to play!