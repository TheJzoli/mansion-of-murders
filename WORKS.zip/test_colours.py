import os


os.system('cls')
print ('\x1b[43;92m')
os.system('cls')

input("Test line press ENTER to exit")


'''
colorama_url = "https://pypi.python.org/pypi/colorama"

try:
	import colorama
except:
	print (
			"Seems like you haven't installed colorama python module.\n"
			"Game will operate normally, but without fancy colors.\n"
			"You can install it from {0}\n".format(colorama_url)
			)
	confirm = input ("Open in browser? (y)").strip()
	if confirm in ['y', 'Y']:
		import webbrowser
		webbrowser.open(colorama_url)
		
		input ("Press ENTER to start Mansion of Murders")
'''
