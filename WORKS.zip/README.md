Mansion of Murders

Text adventure game of solving countless murders as they are happening all over the place. Can you survive the bloodbath?

Project for Python programming and database modeling course.
