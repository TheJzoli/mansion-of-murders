import sqlite3

connection = sqlite3.connect('C:/Users/Leo/Documents/GitHub/mansion-of-murders/distributable/database.db')
cursor = connection.cursor()

cursor.execute("SELECT first_name, last_name FROM npc")
names = cursor.fetchall()

for i in range(len(names)):
	print (str(i) + str(names[i]))
	
connection.close()