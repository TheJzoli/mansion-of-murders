import sqlite3
from os import remove

try:
	remove('C:/Users/Leo/Documents/GitHub/mansion-of-murders/distributable/database.db')
except:
	print ("Removed")
	
sql_file = open('C:/Users/Leo/Documents/GitHub/mansion-of-murders/distributable/create_database_sqlite3.sql', encoding='utf-8-sig')
#sql_file = open('create_database.sql', encoding='utf-8-sig')

sql_lines = sql_file.read()
sql_file.close()

sql_lines = sql_lines.split(sep = "\n")
sql_lines = " ".join([item for item in sql_lines if not (item == '' or item [0:2] == "--")])
sql_lines = sql_lines.replace("\t", " ")
sql_lines = sql_lines.split(sep = ';')
sql_lines = [item + ";" for item in sql_lines if not (item == '' or item [0:2] == "--")]



connection = sqlite3.connect('C:/Users/Leo/Documents/GitHub/mansion-of-murders/distributable/database.db')
cursor = connection.cursor()

for item in sql_lines:
	try:
		print(item)
		cursor.execute(item)
	except sqlite3.OperationalError as e:
		 print(e)
		 break
	
connection.close()	
input("press enter")